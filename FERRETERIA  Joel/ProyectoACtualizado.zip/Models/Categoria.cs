using FERRETERIA__Joel.Helpers;

namespace FERRETERIA__Joel.Models
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string Codigo { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public string? Descripcion { get; set; }
        public decimal PorcentajeGanancia { get; set; }
        public byte Estado { get; set; }
        public DateTime FechaRegistro { get; set; }
        public DateTime? FechaActualizacion { get; set; }
        public int IdEmpleadoResponsable { get; set; }

        public string UrlToken => UrlProtector.Cifrar(IdCategoria.ToString());
    }
}