using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using FERRETERIA__Joel.Factories;
using FERRETERIA__Joel.Models;
using FERRETERIA__Joel.Repositories;

namespace FERRETERIA__Joel.Pages
{
    public class CategoriasModel : PageModel
    {
        private readonly IRepository<Categoria> _repositorio;
        private readonly IModificacionRepository<Categoria> _modificacionRepository;
        private readonly ILogger<CategoriasModel> _logger;

        public string Mensaje { get; set; } = "";
        public List<Categoria> ListCategorias { get; set; } = new();

        [BindProperty(SupportsGet = true)]
        public bool SoloActivos { get; set; }

        public CategoriasModel(
            RepositoryCreator<IRepository<Categoria>> categoriaRepositoryCreator,
            IModificacionRepository<Categoria> modificacionRepository,
            ILogger<CategoriasModel> logger)
        {
            _repositorio = categoriaRepositoryCreator.CreateRepository();
            _modificacionRepository = modificacionRepository;
            _logger = logger;
        }

        public void OnGet(bool? soloActivos)
        {
            SoloActivos = soloActivos ?? false;

            try
            {
                ListCategorias = SoloActivos
                    ? _repositorio.ObtenerActivas()
                    : _repositorio.ObtenerTodos();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al cargar el listado de categorías.");
                Mensaje = "No se pudo cargar el listado de categorías.";
            }
        }

        public IActionResult OnPostEliminar(int id)
        {
            try
            {
                _modificacionRepository.CambiarEstado(id);
                TempData["Mensaje"] = "Categoría desactivada correctamente.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al desactivar la categoría {Id}.", id);
                TempData["MensajeError"] = "No se pudo desactivar la categoría. Inténtalo nuevamente.";
            }
            return RedirectToPage(new { soloActivos = SoloActivos });
        }
    }
}